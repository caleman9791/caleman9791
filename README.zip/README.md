## Hola 👋 
### Mi nombre es Carlos Alemán
<!--
**caleman9791/caleman9791** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->


Algunas cosas sobre mi aquí :


- 🔭 Me encuentro trabajando como proveedor de servicio a mis clientes en [@appcomercial](https://github.com/appcomercial)
- 🔭 Trabajo como tutor para crear aplicaciones web en un entorno LampStack en [@tutorwebenlinea](https://github.com/tutorwebenlinea). 
- 🔭 Actualmente estoy trabajando en varios proyectos y uso la cuenta de [@codefuncode](https://github.com/codefuncode) para publicarlos. 
- 🌱 Actualmente estoy trabajando con APACHE, MYSQL. PHP, JavaScript, CSS3 & HTML5
- 👯 Estoy buscando colaborar en proyectos enfocados a soluciones comerciales. Ya sean estadísticos, arbitrarios, de retención, contabilidad, recursos humanos , inventarios, nominas, facturación y todo lo relacionado a administración  de una empresas u organizaciones.  
- 🤔 Estoy buscando ayuda para financiar productos de aplicaciones web para facilitar los procedimientos dentro de la empresas. 
- 💬 Pregúntame sobre estudio de mercado contabilidad , economía, recursos humos control de inventario, control de usuario, interfaz gratifica, análisis de requerimientos para la organización y relacionados con la administración  de mampresas y como llevar la lógica de negocios a una base de datos para satisfacer todas las necesidades en cuanto la poseso de datos dentro de la misma.  
- 📫 Cómo contactarme: puedes contactarme a través de mi coreo electrónico calemen9791@protonmail.com


<!-- - 😄 Pronombres: ...
- ⚡ Datos divertidos: ...
 -->
