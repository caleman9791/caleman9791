<?php
/*
 * Facturacion en lenguaje PHP
 * Copyright (C) 2008  Daniel Ceillán
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU gv; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 *   Author: Daniel Ceillán           Web Developer
 * Internet: http://classmdp.com.ar   http://proyectohelado.com.ar
 *   E-mail(Pay-pal): codigodaniel@gmail.com 
 *  
 * If you contrib or improve this software, please dont remove my name, add yours as a contributor. 
 * 
 * Contributors or this file:
 * 
 * 
 */
$GLOBALS['Empresa'] = '';

function ver($variable)
{
	$fp = fopen("test.txt","w");
	fputs($fp,print_r($variable,true));
	fclose($fp);
}

function error($mensaje)
{
	return "<script>alert('$mensaje');</script>";
}

function saldo($saldo, $conTexto = 0)
{
	$texto = null;
	if($saldo < 0)
	{
		if($conTexto)$texto = 'debe ';
		$color = '#cc2222';
	}else
	{
		if($conTexto) $texto = 'tiene a favor ';
		$color = '#22cc22';
	}
	return '<span style="font-weight:700;font-size:14px;color:'.$color.';">'.$texto.'<br>'.$saldo.'</span>';
}

//traduce el formato de mysql a dia/mes/anio
function fecha($fecha)
{
	/*
	*/
	if(ereg("-",$fecha))
	{
		$salida = substr($fecha,8,2);
		$salida .= "/".substr($fecha,5,2)."/";
		$salida .= substr($fecha,0,4);
	}else
	{
		$salida = substr($fecha,6,2);
		$salida .= "/".substr($fecha,4,2)."/";
		$salida .= substr($fecha,0,4);
	}
	return $salida;
	/*
	*/
}

//traduce el formato de mysql a dia/mes/anio
function fechaAAnsi($fechaConBarritas)
{
	/*
	*/
	$salida = substr($fecha,8,2);
	$salida .= "/".substr($fecha,5,2)."/";
	$salida .= substr($fecha,0,4);
	return $salida;
	/*
	*/
}




//extrae la hora de un string time traido de la bbdd
function hora($hora)
{
	return substr($hora,0,5);
}

function accionesCliente($htmlHelper, $dataCliente)
{
	$html = $htmlHelper;
		$separador = " | "; 
		echo $html->link('Venderle',
                               '/ventas/edit/0/0/'.$dataCliente['Cliente']['id']);
			echo  $separador;
		echo $html->link('Cobrar',
                               '/cobros/edit/0/a/'.$dataCliente['Cliente']['id'],
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  $separador;
		echo $html->link('Facturar',
                               '/facturas/nueva/a/'.$dataCliente['Cliente']['id'],
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  '<br>';
		echo $html->link('Resumir',
                               '/facturas/nueva/a/'.$dataCliente['Cliente']['id'].'/1',
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  $separador;
		echo $html->link('Ver',
                               '/clientes/view/'.$dataCliente['Cliente']['id'].'/a',
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  $separador;
			//$imagen = '<img src="img/ajustar.jpg" title="Modificarlo...">';
echo $html->link('Modificar',
                               '/clientes/edit/'.$dataCliente['Cliente']['id']);
}

function accionesProveedor($htmlHelper, $data)
{
	$Modelo = 'Proveedor';
	$html = $htmlHelper;
		$separador = " | ";
		echo $html->link('Comprarle',
                               '/compras/edit/0/a/'.$data[$Modelo]['id'],
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  $separador;
			echo $html->link('Pagarle',
                               '/pagos/edit/0/a/'.$data[$Modelo]['id'],
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
	/* *
			echo  $separador;
		echo $html->link('Facturar',
                               '/ventas/facturar/a/'.$dataCliente['Cliente']['id'],
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  '<br>';
		echo $html->link('Resumir',
                               '/ventas/facturar/a/'.$dataCliente['Cliente']['id'].'/1',
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
/**/
			echo  $separador;
		echo $html->link('Ver',
                               '/proveedores/view/'.$data[$Modelo]['id'].'/a',
			array(
			'onclick'=>"return contenido.html(this);"
			)
			);
			echo  $separador;
			//$imagen = '<img src="img/ajustar.jpg" title="Modificarlo...">';
echo $html->link('Modificar',
                               '/proveedores/edit/'.$data[$Modelo]['id']);
/**/
}

function numeroMesAString($numero)

{
	$r = '';
	switch($numero)
	{
		case 1:
			$r = 'enero'; 
		break;
		case 2:
			$r = 'febrero'; 
		break;
		case 3:
			$r = 'marzo'; 
		break;
		case 4:
			$r = 'abril'; 
		break;
		case 5:
			$r = 'mayo'; 
		break;
		case 6:
			$r = 'junio'; 
		break;
		case 7:
			$r = 'julio'; 
		break;
		case 8:
			$r = 'agosto'; 
		break;
		case 9:
			$r = 'setiembre'; 
		break;
		case 10:
			$r = 'octubre'; 
		break;
		case 11:
			$r = 'noviembre'; 
		break;
		case 12:
			$r = 'diciembre'; 
		break;
	}
	return $r;
}

function puntoPorComa($string)
{
	return str_replace  ('.', ',',$string  ); 
}

class CCC
{
	var $modeloPago = 'Pago';
	var $modeloCompra = 'Compra';
	var $campoIdPago = 'pago_id';
	var $campoIdCompra = 'compra_id';
	var $pagos = null;
	var $compras = null;
	var $debil = null;
	var $entidadDebil = 'Pagoacompra';
	
	function CCC($compras, $pagos)
	{
		$this->pagos = $this->arreglo($pagos);
		$this->compras = $this->arreglo($compras);		
		$this->debil = array();
	}
	
	function arreglo($arreglo)
	{
		if(!isset($arreglo[0]))
		{
			$aux = array();
			foreach($arreglo as $el)
			{
				array_push($aux, $el);
			}
			$arreglo = $aux;
		}
		return $arreglo;
	}
	
	function cambiarAVentas()
	{
		$this->campoIdCompra = 'venta_id';
		$this->campoIdPago = 'cobro_id';
		$this->entidadDebil = 'Pagoaventa';
		$this->modeloCompra = 'Venta';
		$this->modeloPago = 'Cobro';
	}
	
	function ejecutar()
	{
		$modeloPago = $this->modeloPago;
		$modeloCompra = $this->modeloCompra;
		$campoIdPago = $this->campoIdPago;
		$campoIdCompra = $this->campoIdCompra;
		$entidadDebil = $this->entidadDebil;
		$saldo = 0;
		for($p=0; $p < count($this->pagos); $p++)
		{
			$idPago = $this->pagos[$p][$modeloPago]['id'];
			$monto = $this->pagos[$p][$modeloPago]['resto'];
			for($c=0; $c < count($this->compras); $c++)
			{
				$deuda = $this->compras[$c][$modeloCompra]['debe'];
				$idCompra = $this->compras[$c][$modeloCompra]['id'];
				if($monto > 0 && $deuda > 0)
				{
					if($deuda > $monto)
					{
						$deuda = $deuda - $monto;
						$aplicado = $monto;
						$monto = 0;
					}else
					{
						$monto = $monto - $deuda;
						$aplicado = $deuda;
						$deuda = 0;
					}
					$this->compras[$c][$modeloCompra]['debe'] = $deuda;
					$cancelacion = array();
					$cancelacion[$entidadDebil][$campoIdCompra] = $idCompra;
					$cancelacion[$entidadDebil][$campoIdPago] = $idPago;
					$cancelacion[$entidadDebil]['valor'] = $aplicado;
					$cancelacion[$entidadDebil]['id'] = null;
					array_push($this->debil, $cancelacion);
				}
			}
			$this->pagos[$p][$modeloPago]['resto'] = $monto;
			$saldo += $monto;
		}
		foreach($this->compras as $c)
		{
			$deuda = $c[$modeloCompra]['debe'];
			$saldo -= $deuda;
		}
		return $saldo;
	}
}
?>
