/*
 * Facturacion en lenguaje PHP
 * Copyright (C) 2008  Daniel Ceill�n
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU gv; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 *   Author: Daniel Ceill�n           Web Developer
 * Internet: http://classmdp.com.ar   http://proyectohelado.com.ar
 *   E-mail(Pay-pal): codigodaniel@gmail.com 
 *  
 * If you contrib or improve this software, please dont remove my name, add yours as a contributor. 
 * 
 * Contributors or this file:
 * 
 * 
 */

function ajaxController(nombreCapaString)
{
	this.destino = $(nombreCapaString);
	
	/*					CONFIRMAR AJAX
 * ejecuta una peticion ajax previa confirmacion mediante un alert con la pregunta
 * url -> origen de datos
 * destino -> string con el nombre de la capa Dojo (si es LayoutContainer no funciona ningun ajax)
 * pregunta -> la pregunta que se le hace al usuario
 */

this.confirmar = function (vinculo, pregunta)
{
	 if(confirm(pregunta)) 
	 { 
		this.html(vinculo);
     }
	 return false;
}

	this.html = function(vinculo)
	{
		procesando();
		
		var url = vinculo.href;
	
	/**/
		var destino = this.destino;
						new Ajax(url, {
							method: 'get',
							update: destino,
							evalScripts: true,
							evalResponse : false,
							onComplete: function(xml) {	
								//destino.removeClass('ajax-loading');								
								//this.evalScripts();
								procesado();
							}
						}).request();
						/**/
		return false;
	}
	
	
/*					FORMUAJAX
 * ejecuta una peticion ajax a traves de un formulario
 * vinculo -> referencia al vinculo
 * destino -> string con el nombre de la capa Dojo (si es LayoutContainer no funciona ningun ajax)
 * EJEMPLO
 * <a onclick="return cargaHtml(this,'nombreDeLaCapaDojo');">vinculo</a>
 */
	this.formulario = function (formulario)
	{
		//alert(f.action);
		if(validaform(formulario))
		{
		espera = this.espera;	
		espera.mostrar();
		destino = this.destino;
		dojo.io.bind
		(
			{
				url: formulario.action,
				formNode: formulario,
				load: function(type,data)
				{
					dojo.widget.byId(destino).setContent(data);
					espera.esconder();
					
				},
				method: "POST"
			}
		);
		}
		return false;
	}
		
}//fin objeto ajax

          function linkAjax(link,destino)
		  {
					   // destino.empty().addClass('ajax-loading');
				
						new Ajax(link, {
							method: 'get',
							update: destino,
							evalScripts: false,
							evalResponse : false,
							onComplete: function(xml) {	
																			
								//destino.removeClass('ajax-loading');								
												
								this.evalScripts();
										
							}
						}).request();
           
         }

          function FormAjax(form,destino) {
                 
                    //new Event(e).stop();				
					destino.addClass('ajax-loading');

					form.send({
						update: destino,
						evalScripts: false,
						onComplete: function() {
								destino.removeClass('ajax-loading');								
								refreshBarra();						
								this.evalScripts();
							
						}
					});
                   
				return false;
               }                 
               
           function submitform(e){
		   	  		      
				var misForms = $$('form');
				//me fijo de que form es hijo el elemento
				misForms.each(function(elemento)
				{  
				   if(elemento.hasChild(e)){		
				       		   	  
					   //var capas = $$('input',['capaAjax']);
					   var destino = 'contenidoAjax';
					   //verifico si tengo que refrescar en otro div ajax diferente
					   if (elemento.capaAjax){
					     destino = elemento.capaAjax.value;
						}                      
					  FormAjax(elemento,$(destino));                      				   	 
				   }

				});
				
           }
          
   
		  
     