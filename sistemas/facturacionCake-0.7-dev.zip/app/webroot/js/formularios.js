/*
 * Facturacion en lenguaje PHP
 * Copyright (C) 2008  Daniel Ceill�n
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU gv; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 *   Author: Daniel Ceill�n           Web Developer
 * Internet: http://classmdp.com.ar   http://proyectohelado.com.ar
 *   E-mail(Pay-pal): codigodaniel@gmail.com 
 *  
 * If you contrib or improve this software, please dont remove my name, add yours as a contributor. 
 * 
 * Contributors or this file:
 * 
 * 
 */
function FormularioController()
{
	this.formulario = document.forms[0];
	
	this.setFormulario = function(idString)
	{
		this.formulario = document.getElementById(idString);
	}
	
	this.decimales = function(valor)
	{
		return valor.toFixed(2);
	}
	
	this.leer = function(punteroACampo)
	{
		var campo = punteroACampo;
		isNaN(campo.value);
		if(!campo.value || isNaN(campo.value))
		{
			valor = 0;
		}else
		{
			valor = parseFloat (campo.value);
		}
		return valor;
	}
	this.campo = function(id)
	{
		return document.getElementById(id);
	}
	
	this.submit = function(formulario)
	{
		salida = this.actualizar(); 
		if(salida != false) salida = formulario.seguro.checked; 		
		return salida;
	}
	
	this.actualizar = function()
	{
		return this.algoritmo();
	}
	
	this.tildarTodo = function()
	{
		if(this.formulario != null)
		{
			for(var x=0; x < this.formulario.length; x++)
			{
				if(this.formulario[x].type == 'checkbox')
				this.formulario[x].checked = true;
			}
		}
	}
	
	this.algoritmo = function()
	{
		return true;
	}
}

var formu = new FormularioController();

var campos = new Array();

function ventaForm()
{
	campos.length = 0;
	 campos[0] = this.campo('VentaBidon8');
	 campos[1] = this.campo('VentaBidon8p');
	 campos[2] = this.campo('VentaBidon10');
	 campos[3] = this.campo('VentaBidon10p');
	 campos[4] = this.campo('VentaBidon20');
	 campos[5] = this.campo('VentaBidon20p');
	 campos[6] = this.campo('VentaDispenser');
	 campos[7] = this.campo('VentaDispenserp');
	 campos[8] = this.campo('VentaVasosx100');
	 campos[9] = this.campo('VentaVasosx100p');
	 
	c_descuento = this.campo('VentaDescuento');
	c_total = this.campo('VentaTotal');
	
	//copio la fecha
	this.campo('VentaFecha').value = this.leer('fecha');
	
	var descuento = this.leer(c_descuento);
	if(descuento > 100 || descuento < 0 )
	{
		descuento = 0;
		alert("el descuento debe estar entre 0 y 100");
	}
	
	c_descuento.value = descuento;
	var total = 0;
	
	
	for (var i = 0; i < campos.length; i= i + 2) 
	{
		campos[i].value = this.leer(campos[i]);
		campos[i + 1].value = this.leer(campos[i + 1]);
		total = total + campos[i].value * campos[i + 1].value;
		campos[i + 1].value = this.decimales (this.leer(campos[i + 1]));
	}
	
	total = total * ( 100 - descuento)  / 100;
	c_total.value = this.decimales (total);
	  
}

function pagoForm()
{
	//alert('pagoForm');
	/* *
	 campos[0] = this.campo('VentaBidon8');
	 campos[1] = this.campo('VentaBidon8p');
	 campos[2] = this.campo('VentaBidon10');
	 campos[3] = this.campo('VentaBidon10p');
	 campos[4] = this.campo('VentaBidon20');
	 campos[5] = this.campo('VentaBidon20p');
	 campos[6] = this.campo('VentaDispenser');
	 campos[7] = this.campo('VentaDispenserp');
	 campos[8] = this.campo('VentaVasosx100');
	 campos[9] = this.campo('VentaVasosx100p');
	 
	c_descuento = this.campo('VentaDescuento');
	c_total = this.campo('VentaTotal');
	
	//copio la fecha
	this.campo('VentaFecha').value = this.leer('fecha');
	
	var descuento = this.leer(c_descuento);
	if(descuento > 100 || descuento < 0 )
	{
		descuento = 0;
		alert("el descuento debe estar entre 0 y 100");
	}
	
	c_descuento.value = descuento;
	var total = 0;
	
	
	for (var i = 0; i < campos.length; i= i + 2) 
	{
		campos[i].value = this.leer(campos[i]);
		campos[i + 1].value = this.leer(campos[i + 1]);
		total = total + campos[i].value * campos[i + 1].value;
		campos[i + 1].value = this.decimales (this.leer(campos[i + 1]));
	}
	
	total = total * ( 100 - descuento)  / 100;
	c_total.value = this.decimales (total);
	/* */
}

function ventaEnFacturaForm()
{
	var elemento = null;
	var salida = false;
	for(var x=0; x < document.forms[0].length; x++)
	{
		elemento = document.forms[0][x];
		if(elemento.type == 'checkbox' && elemento.name != 'seguro')
		if(elemento.checked == true) salida = true;
	}
	if(!salida) alert('Debe tildar al menos una venta.');
	return salida;
}

function facturaForm()
{
	
	/* *
	var elemento = null;
	var salida = false;
	for(var x=0; x < document.forms[0].length; x++)
	{
		elemento = document.forms[0][x];
		if(elemento.type == 'checkbox' && elemento.name != 'seguro')
		if(elemento.checked == true) salida = true;
	}
	if(!salida) alert('Debe tildar al menos una venta.');
	return salida;
	/* */
}











/* *

	this.actualizar = function()
	{
		formu = document.forms[0];
		
		var iva = this.leer(formu.porcientoiva);

		if(iva < 0 || iva > 100)
		{
			iva = this.factura.porcientoIva;
		}else
		{
			this.factura.porcientoIva = iva;
		}
		
		iva =(100 + iva) / 100;
		this.factura.subtotal2 = this.factura.total / iva;

		this.factura.montoIva = this.factura.total - this.factura.subtotal2;
		
		this.factura.impuesto = this.leer(formu.impuesto);
		if(this.factura.impuesto > this.factura.subtotal2)
		{
			this.factura.impuesto = 0;
		}
		
		this.factura.subtotal1 = this.factura.subtotal2 - this.factura.impuesto;
		
		var indice = this.factura.subtotal1 / this.factura.total;

		this.factura.detalle.actualizar(indice);

		this.mostrar();

	}
	
	this.mostrar = function()
	{
		formu = document.forms[0];
		formu.total.value = this.factura.total;
		formu.porcientoiva.value = this.factura.porcientoIva;
		formu.montoiva.value = this.decimales(this.factura.montoIva); 
		formu.subtotal2.value = this.decimales( this.factura.total -formu.montoiva.value);
		formu.subtotal1.value = this.decimales( this.factura.subtotal1);
		formu.impuesto.value = this.factura.impuesto;
	}

/* */

var facturas = new Array();

function nroFac()
{
	var num1 = '0';
	var num2 = '1';
	var error = 'error';
	
	while(error != '')
	{
		error = '';
		num1 = '';
		num2 = '';
		num1 = prompt("Ingrese el n�mero de Factura...");
		
		for(var x = 0; x < facturas.length; x++)
		{
			if(facturas[x] == num1) error += '\nEse numero de factura ya está registrado...'
		}
		
		if(num1.charAt(4) != '-')
		{
			error += '\nFormato incorrecto debe ser ####-########';
		}
		
		num2 = prompt("Ingrese nuevamente el n�mero de Factura...");
		
		if(num2.charAt(4) != '-')
		{
			error = error + '\nFormato incorrecto debe ser ####-########';
		}
		if(num1 != num2)
		{
			error = error + '\nEl numero de Factura fue ingresado erroneamente...\n' + num1 + '\n' + num2;
		}
		
		
		if(error) alert(error);
		
	}
	$('facturaNumero').value = num1;
}

function ivaventasForm()
{
	return true;
}

function compraForm()
{
	var detalle = this.campo('CompraDetalle');
	var tipodoc = this.campo('CompraTipodoc');
	var nrodoc = this.campo('CompraNrodoc');
	var seguro = this.campo('seguro');
	var neto = this.campo('CompraNeto');
	var importe_IVA = this.campo('CompraImporteIVA');
	var nogravados = this.campo('CompraNogravados');
	var retenciones = this.campo('CompraRetenciones');
	var total = this.campo('CompraTotal');
	var salida = true;
	
	total.value = this.leer(total);
	neto.value = this.leer(neto);
	importe_IVA.value = this.leer(importe_IVA);
	nogravados.value = this.leer(nogravados);
	retenciones.value = this.leer(retenciones);

	if(seguro.checked)
	{
		if(!detalle.value)
		{
			alert('Debe ingresar un detalle.');
			salida = false;
		} 
		if(!tipodoc.value)
		{
			alert('Debe ingresar un tipo de documento.');
			salida = false;
		} 
		if(!nrodoc.value)
		{
			alert('Debe ingresar un numero de documento.');
			salida = false;
		} 

		if(neto.value == 0)
		{
			alert('Debe ingresar un neto válido. Para decimales use el punto.');
			salida = false;
		}
		if(importe_IVA.value == 0)
		{
			alert('Debe ingresar un importe de IVA facturado. Para decimales use el punto.');
			salida = false;
		}
		if(total.value == 0)
		{
			alert('Debe ingresar un total válido. Para decimales use el punto.');
			salida = false;
		}
	}
	
	return salida;
}

function facturaSueltaForm()
{
	campos.length = 0;
	 campos.push(this.campo('FacturaBidon8'));
	 campos.push(this.campo('FacturaBidon8p'));
	 campos.push(this.campo('FacturaBidon8t'));
	 campos.push(this.campo('FacturaBidon10'));
	 campos.push(this.campo('FacturaBidon10p'));
	 campos.push(this.campo('FacturaBidon10t'));
	 campos.push( this.campo('FacturaBidon20'));
	 campos.push( this.campo('FacturaBidon20p'));
	 campos.push( this.campo('FacturaBidon20t'));
	 campos.push( this.campo('FacturaDispenser'));
	 campos.push( this.campo('FacturaDispenserp'));
	 campos.push( this.campo('FacturaDispensert'));
	 campos.push( this.campo('FacturaVasosx100'));
	 campos.push( this.campo('FacturaVasosx100p'));
	 campos.push( this.campo('FacturaVasosx100t'));
	 
	c_descuento = this.campo('FacturaDescuento');
	c_subtotal = this.campo('FacturaSubTotal');
	c_montoIva = this.campo('FacturaMontoIVA');
	c_total = this.campo('FacturaTotal');
	c_porciento = this.campo('FacturaPorcentajeIVA');
	incluyeiva = this.campo('FacturaIvaincluido');
	
	//copio la fecha
	//this.campo('VentaFecha').value = this.leer('fecha');
	
	var descuento = this.leer(c_descuento);
	if(descuento > 100 || descuento < 0 )
	{
		descuento = 0;
		alert("el descuento debe estar entre 0 y 100");
	}
	var porciento = this.leer(c_porciento);
	if(porciento > 100 || porciento < 0 )
	{
		porciento = 0;
		alert("el porcentaje debe estar entre 0 y 100");
	}
	
	c_descuento.value = descuento;
	c_porciento.value = porciento;
	
	var total = 0;
	var auxiliar = 0;

		
		for (var i = 0; i < campos.length; i= i + 3) 
		{
			campos[i].value = this.leer(campos[i]);
			campos[i + 1].value = this.leer(campos[i + 1]);
			total = total + campos[i].value * campos[i + 1].value;
			campos[i + 2].value = campos[i].value * campos[i + 1].value;
			campos[i + 1].value = this.decimales (this.leer(campos[i + 1]));
			campos[i + 2].value = this.decimales (this.leer(campos[i + 2]));
		}
		
		total = total * ( 100 - descuento)  / 100;
		c_subtotal.value = this.decimales (total);
		c_montoIva.value = this.decimales( c_subtotal.value * c_porciento.value / 100 );
		total = total + this.leer(c_montoIva);
		c_total.value = this.decimales (total);	
				
		

		
}

function incluyeIva()
{
	campos.length = 0;
	 campos.push(formu.campo('FacturaBidon8'));
	 campos.push(formu.campo('FacturaBidon8p'));
	 campos.push(formu.campo('FacturaBidon8t'));
	 campos.push(formu.campo('FacturaBidon10'));
	 campos.push(formu.campo('FacturaBidon10p'));
	 campos.push(formu.campo('FacturaBidon10t'));
	 campos.push( formu.campo('FacturaBidon20'));
	 campos.push( formu.campo('FacturaBidon20p'));
	 campos.push( formu.campo('FacturaBidon20t'));
	 campos.push( formu.campo('FacturaDispenser'));
	 campos.push( formu.campo('FacturaDispenserp'));
	 campos.push( formu.campo('FacturaDispensert'));
	 campos.push( formu.campo('FacturaVasosx100'));
	 campos.push( formu.campo('FacturaVasosx100p'));
	 campos.push( formu.campo('FacturaVasosx100t'));
	 
	c_descuento = formu.campo('FacturaDescuento');
	c_subtotal = formu.campo('FacturaSubTotal');
	c_montoIva = formu.campo('FacturaMontoIVA');
	c_total = formu.campo('FacturaTotal');
	c_porciento = formu.campo('FacturaPorcentajeIVA');
	incluyeiva = formu.campo('FacturaIvaincluido');
	
	//copio la fecha
	//this.campo('VentaFecha').value = this.leer('fecha');
	
	var descuento = formu.leer(c_descuento);
	if(descuento > 100 || descuento < 0 )
	{
		descuento = 0;
		alert("el descuento debe estar entre 0 y 100");
	}
	var porciento = formu.leer(c_porciento);
	if(porciento > 100 || porciento < 0 )
	{
		porciento = 0;
		alert("el porcentaje debe estar entre 0 y 100");
	}
	
	c_descuento.value = descuento;
	c_porciento.value = porciento;
	
	var total = 0;
	var auxiliar = 0;
	var totalAnterior = 0;
		for (var i = 0; i < campos.length; i= i + 3) 
		{
			auxiliar = 0;
			campos[i].value = formu.leer(campos[i]);
			totalAnterior += campos[i].value * campos[i + 1].value;
			campos[i + 1].value = formu.leer(campos[i + 1])/ ((100 + porciento) / 100);
			auxiliar = campos[i].value * campos[i + 1].value;
			total = total + auxiliar;
			campos[i + 2].value = auxiliar;
			campos[i + 1].value = formu.decimales (formu.leer(campos[i + 1]));
			campos[i + 2].value = formu.decimales (formu.leer(campos[i + 2]));
		}
		total = total * ( 100 - descuento)  / 100;
		totalAnterior = totalAnterior * ( 100 - descuento)  / 100;
		c_subtotal.value = formu.decimales (total);
		c_montoIva.value = formu.decimales( totalAnterior - total );
		c_total.value = formu.decimales (totalAnterior);
		$('incluyeiva').setStyle('visibility','hidden');
	return false;
}

function setCondicionIva(texto, porcentaje)
{
	$('FacturaCondicionIva').value = texto;
	$('FacturaPorcentajeIVA').value = porcentaje;
}